=== Plugin Name ===
Contributors: jfoucher
Donate link: http://jfoucher.com.com/
Tags: error, 404, email, notification
Requires at least: 2.0.2
Tested up to: 3.0.4
Stable tag: 0.1

Send the site administrator an email when someone encounters a 404 error on your blog

== Description ==

A very simple plugin that sends the main site administrator an email when one of your visitors encounters a 404 error

== Installation ==

The usual

1. Upload `email-404` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Sorry, no 3...

== Screenshots ==

Nothing to show

== Changelog ==

= 0.1 =
* Initial release

